function varargout = CSTR(varargin)
% CSTR M-file for CSTR.fig
%      CSTR, by itself, creates a new CSTR or raises the existing
%      singleton*.
%
%      H = CSTR returns the handle to a new CSTR or the handle to
%      the existing singleton*.
%
%      CSTR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CSTR.M with the given input arguments.
%
%      CSTR('Property','Value',...) creates a new CSTR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CSTR_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CSTR_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CSTR

% Last Modified by GUIDE v2.5 17-Sep-2012 02:29:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CSTR_OpeningFcn, ...
                   'gui_OutputFcn',  @CSTR_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CSTR is made visible.
function CSTR_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CSTR (see VARARGIN)

% Choose default command line output for CSTR
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CSTR wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = CSTR_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%  axes(handles.axes3);
 axes(handles.axes3)
 

   moon = imread('CstrOpenLoop.jpg');
imshow(moon)
      axes(handles.axes4)

% 
   moon = imread('shiraz_uni_english.jpg');
imshow(moon)
% --- Executes on button press in simulate_button.
function simulate_button_Callback(hObject, eventdata, handles)
% hObject    handle to simulate_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Step test for Model 1 - CSTR
% Created by John Hedengren

% T : tempertire of product
% Tcoolant temperture of jacket;


global Ca_ss T_ss Tcoolant_ss x_ss
global Tcf qc qc_store Tcf_store
global Ca T Tcoolant
global previous_setpoint_outer  previous_setpoint_inner
global T_current_store  sample_rate_for_ziegler controllergain_for_ziegler
global T_product_store

cla(handles.axes1,'reset')
cla(handles.axes2,'reset')

set(handles.min_temp_static,'visible','off');
set(handles.text118,'visible','off');
set(handles.max_temp_static,'visible','off');
set(handles.text117,'visible','off');

T_product_store=[];

set(handles.measured_data_text,'visible' , 'off' );
set(handles.estimated_model_text,'visible' , 'off' );

start_simulation_time=str2double(get(handles.start_simulation_hidden,'string'));
end_simulation_time=str2double(get(handles.end_time_hidden,'string'));
sample_rate=str2double(get(handles.sample_rate_hidden,'string'));

    t_for_simulation=[0:sample_rate:end_simulation_time];
    
qc=str2double(get(handles.outlet_flow_edit,'string'));
    if qc>70
        errordlg('Process input should be less than 70 lb/min ', ' Error: ');
        set(handles.outlet_flow_edit,'string',70)
        return
    end

    if qc<0.5
        errordlg('Process input should be more than 0.5 lb/min ', ' Error: ');
        set(handles.outlet_flow_edit,'string',0.5)
        return
    end

qc_store=[qc_store qc];
set(handles.jacket_flowrate_pic,'string',qc);

Tcf=str2double(get(handles.dist_temp,'string'));
    if Tcf>50
        errordlg('Maximum Process disturbance is 50 `C ', ' Error: ');
        set(handles.dist_temp,'string',50)
        return
    end
    if Tcf<20
        errordlg('Minimum Process disturbance is 20 `C ', ' Error: ');
        set(handles.dist_temp,'string',20)
        return
    end
Tcf=Tcf+273;
Tcf_store=[Tcf_store Tcf];

% Steady State Initial Conditions for the States
if str2double(get(handles.simulation_counter,'string'))==0
    
Ca_ss = 0.51;
Ca=Ca_ss;

T_ss = 273+60;
T=T_ss;
Tcoolant_ss=273+50;
Tcoolant=Tcoolant_ss;
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%% Primary Manual Mode && Secondry Manual Mode: 
if get(handles.cntr_menu_p,'value')==1 && get(handles.cntr_menu_s,'value')==1 ;
[t,x] = ode15s('cstr1',[0:sample_rate:end_simulation_time],x_ss);

% Parse out the state values
Ca = x(:,1);
T = x(:,2);
Tcoolant=x(:,3);
T_product_store=T;
% ploting:
     for i=1:length(T);
hold(handles.axes1,'on')
plot(handles.axes1,t(i),T(i)-273,'r.:','markersize',4.8);
axis(handles.axes1,[start_simulation_time end_simulation_time 30 120]);
set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant(i)-273));

hold(handles.axes2,'on')
plot(handles.axes2,t(i),Tcoolant(i)-273,'b.:','markersize',5);
axis(handles.axes2,[start_simulation_time end_simulation_time 30 120]);
set(handles.axes2,'xtick',[])
set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T(i)-273));
pause(0.05);

     end
     Ca_ss =x(size(x,1),1);
T_ss = x(size(x,1),2);
Tcoolant_ss=x(size(x,1),3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];

end





setpoint_outer=str2double(get(handles.set_point_p_edit,'string'));
    if setpoint_outer<40
        errordlg('Minimum Setpoint is 40 `C ', ' Error: ');
        set(handles.set_point_p_edit,'string',40)
        return
    end
    if setpoint_outer>110
        errordlg('Maximum Setpoint is 110 `C ', ' Error: ');
        set(handles.set_point_p_edit,'string',110)
        return
    end
    
setpoint_inner=str2double(get(handles.set_point_s_edit,'string'));

    if setpoint_inner<40
        errordlg('Minimum Setpoint is 40 `C ', ' Error: ');
        set(handles.set_point_s_edit,'string',40)
        return
    end
    if setpoint_inner>110
        errordlg('Maximum Setpoint is 110 `C ', ' Error: ');
        set(handles.set_point_s_edit,'string',110)
        return
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Primary P && Secondry Manual Mode: 
if get(handles.cntr_menu_p,'value')==2  && get(handles.cntr_menu_s,'value')==1 ;
    
                      set(handles.primary_p_flag,'string',1);
    
    setpoint_outer=str2double(get(handles.set_point_p_edit,'string'));
    T_current_store=[];
    % set_point_p_edit    :  p==product
               if str2double(get(handles.setpoint_outer_counter,'string'))==0; 
                   hold(handles.axes1,'on');
                   plot(handles.axes1,[0   end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
               if str2double(get(handles.setpoint_outer_counter,'string'))==1; 
                   hold(handles.axes1,'on')
                   plot(handles.axes1,[-end_simulation_time/10 0],[previous_setpoint_outer    previous_setpoint_outer],'m');
                   plot(handles.axes1,[0    0],[previous_setpoint_outer     setpoint_outer],'m');
                   plot(handles.axes1,[0    end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
        
     
    % P= Primary loop
    % S= secondary loop
                t_sim=0:sample_rate:end_simulation_time;
                setpoint_p=str2double(get(handles.set_point_p_edit,'string'));
                setpoint_p=setpoint_p+273;
                controllergain_p=str2double(get(handles.kc_edit_p,'string'));
                controllergain_for_ziegler = controllergain_p;
                controll_bias_p=str2double(get(handles.contoroller_bias_edit_p,'string'));
                T_current=x_ss(2);
                
                sample_rate_for_ziegler=str2double(get(handles.sample_rate_hidden,'string'));
                
                 for i=1:length(t_for_simulation)
        % P concept:
                   error=setpoint_p - T_current;
                   qc = controll_bias_p + controllergain_p * error;
                   
                  if qc>70
                       qc=70;
                   end
                   if qc<=0
                       qc=0.01;
                   end
                   set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                   
                   
                   tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  T_current_store=[T_current_store T_current];
                  Tcoolant_current=x(2,3);
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
%                   T_current = x(2,2);
%                    Tcoolant_current=x(2,3);
                   % plotting:
                   hold(handles.axes1,'on')
                   plot(handles.axes1,tspan(2),T_current-273,'r.:','markersize',4.8);
                   axis(handles.axes1,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));
                   

                   hold(handles.axes2,'on')
                   plot(handles.axes2,tspan(2),Tcoolant_current-273,'b.:','markersize',5);
                   axis(handles.axes2,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.axes2,'xtick',[])
                   set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                   pause(0.05);
                   
                   
                 end
                  set(handles.setpoint_outer_counter,'string',1);
                  set(handles.simulation_counter,'string',1);
                  T_product_store=T_current_store;
Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Primary PI && Secondry Manual Mode: 
if get(handles.cntr_menu_p,'value')==3 && get(handles.cntr_menu_s,'value')==1;
    setpoint_outer=str2double(get(handles.set_point_p_edit,'string'));
      error=0;
    % set_point_p_edit    :  p==product
               if str2double(get(handles.setpoint_outer_counter,'string'))==0; 
                   hold(handles.axes1,'on');
                   plot(handles.axes1,[0   end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
               if str2double(get(handles.setpoint_outer_counter,'string'))==1; 
                   hold(handles.axes1,'on')
                   plot(handles.axes1,[-end_simulation_time/10 0],[previous_setpoint_outer    previous_setpoint_outer],'m');
                   plot(handles.axes1,[0    0],[previous_setpoint_outer     setpoint_outer],'m');
                   plot(handles.axes1,[0    end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
        
     
    % P= Primary loop
    % S= secondary loop
                t_sim=0:sample_rate:end_simulation_time;
                setpoint_p=str2double(get(handles.set_point_p_edit,'string'));
                setpoint_p=setpoint_p+273;
                controllergain_p=str2double(get(handles.kc_edit_p,'string'));
                T_current=x_ss(2);
                reset_time_p=str2double(get(handles.reset_time_edit_p,'string'));
                 initial_qc=str2double(get(handles.jacket_flowrate_pic,'string'));
                 
                 for i=1:length(t_for_simulation)
        % P concept:
                   currenterror=setpoint_p - T_current;
                   error=error + setpoint_p - T_current;
                   qc = initial_qc  +  controllergain_p* currenterror  +   (sample_rate*controllergain_p/reset_time_p)*error;
                   if qc>70
                       qc=70;
                   end
                   if qc<=0
                       qc=0.01;
                   end
                   set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                   
                   
                   tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  T_product_store=[T_product_store T_current];
                  Tcoolant_current=x(2,3);
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
%                   T_current = x(2,2);
%                    Tcoolant_current=x(2,3);
                   % plotting:
                   hold(handles.axes1,'on')
                   plot(handles.axes1,tspan(2),T_current-273,'r.:','markersize',4.8);
                   axis(handles.axes1,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));
                   

                   hold(handles.axes2,'on')
                   plot(handles.axes2,tspan(2),Tcoolant_current-273,'b.:','markersize',5);
                   axis(handles.axes2,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.axes2,'xtick',[])
                   set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                   pause(0.05);
                   
                   
                 end
                  set(handles.setpoint_outer_counter,'string',1);
                  set(handles.simulation_counter,'string',1);
Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%% Primary PID && Secondry Manual Mode: 

if get(handles.cntr_menu_p,'value')==4 && get(handles.cntr_menu_s,'value')==1;
    % P= Primary loop
    % S= secondary loop
        setpoint_outer=str2double(get(handles.set_point_p_edit,'string'));
        % set_point_p_edit    :  p==product
               if str2double(get(handles.setpoint_outer_counter,'string'))==0; 
                   hold(handles.axes1,'on');
                   plot(handles.axes1,[0   end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
               if str2double(get(handles.setpoint_outer_counter,'string'))==1; 
                   hold(handles.axes1,'on')
                   plot(handles.axes1,[-end_simulation_time/10 0],[previous_setpoint_outer    previous_setpoint_outer],'m');
                   plot(handles.axes1,[0    0],[previous_setpoint_outer     setpoint_outer],'m');
                   plot(handles.axes1,[0    end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
               
                error=0;
                t_sim=0:sample_rate:end_simulation_time;
                setpoint_p=str2double(get(handles.set_point_p_edit,'string'));
                setpoint_p=setpoint_p+273;
                controllergain_p=str2double(get(handles.kc_edit_p,'string'));
                reset_time_p=str2double(get(handles.reset_time_edit_p,'string'));
                
                derive_time_p=str2double(get(handles.derive_time_edit_p,'string')); 
                T_current=x_ss(2);
                
                initial_qc=str2double(get(handles.jacket_flowrate_pic,'string'));
                
                previouserror = setpoint_p - T_current;
                
                 for i=1:length(t_for_simulation)
        % PID concept:
                   currenterror=setpoint_p - T_current;
                   error=error + setpoint_p - T_current;
                   qc =  initial_qc  +  controllergain_p * currenterror  +   (sample_rate*controllergain_p/reset_time_p)*error + (controllergain_p*derive_time_p/sample_rate)*(currenterror-previouserror);
                   previouserror=currenterror;
                   
                  if qc>80
                       qc=80;
                   end
                   if qc<=0
                       qc=0.01;
                   end
                   set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                   
                   
                   tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  Tcoolant_current=x(2,3);
                  T_product_store=[T_product_store T_current];
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
%                   T_current = x(2,2);
%                    Tcoolant_current=x(2,3);
                   % plotting:
                   hold(handles.axes1,'on')
                   plot(handles.axes1,tspan(2),T_current-273,'r.:','markersize',4.8);
                   axis(handles.axes1,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));
                   

                   hold(handles.axes2,'on')
                   plot(handles.axes2,tspan(2),Tcoolant_current-273,'b.:','markersize',5);
                   axis(handles.axes2,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.axes2,'xtick',[])
                   set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                   pause(0.05);
                   
                   
                 end
                 set(handles.setpoint_outer_counter,'string',1);
                 set(handles.simulation_counter,'string',1);
Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Primary Manual Mode && Secondry P: 

if get(handles.cntr_menu_p,'value')==1 && get(handles.cntr_menu_s,'value')==2;
    % P= Primary loop
    % S= secondary loop
        setpoint_inner=str2double(get(handles.set_point_s_edit,'string'));
        % set_point_p_edit    :  p==product
               if str2double(get(handles.setpoint_inner_counter,'string'))==0; 
                   hold(handles.axes2,'on');
                   plot(handles.axes2,[0   end_simulation_time],[setpoint_inner     setpoint_inner],'m');
                   previous_setpoint_inner=setpoint_inner;
               end 
               if str2double(get(handles.setpoint_inner_counter,'string'))==1; 
                   hold(handles.axes2,'on')
                   plot(handles.axes2,[-end_simulation_time/10 0],[previous_setpoint_inner    previous_setpoint_inner],'m');
                   plot(handles.axes2,[0    0],[previous_setpoint_inner     setpoint_inner],'m');
                   plot(handles.axes2,[0    end_simulation_time],[setpoint_inner     setpoint_inner],'m');
                   previous_setpoint_inner=setpoint_inner;
               end 
               
              
                t_sim=0:sample_rate:end_simulation_time;
                setpoint_s=str2double(get(handles.set_point_s_edit,'string'));
                setpoint_s = setpoint_s + 273;
                controllergain_s=str2double(get(handles.kc_edit_s,'string'));

                controllerbias_s=str2double(get(handles.contoroller_bias_edit_s,'string'));

                Tcoolant_current=x_ss(3);

                
                 for i=1:length(t_for_simulation)
        % P concept:
                   currenterror= setpoint_s - Tcoolant_current;
%                    error=error + setpoint_p - T_current;
                   qc =  controllerbias_s  +  controllergain_s * currenterror  ;
                   
                  if qc>80
                       qc=80;
                   end
                   if qc<=0
                       qc=0.01;
                   end
                   set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                   
                   
                   tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  T_product_store=[T_product_store T_current];
                  Tcoolant_current=x(2,3);
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
%                   T_current = x(2,2);
%                    Tcoolant_current=x(2,3);
                   % plotting:
                   hold(handles.axes1,'on')
                   plot(handles.axes1,tspan(2),T_current-273,'r.:','markersize',4.8);
                   axis(handles.axes1,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));
                   

                   hold(handles.axes2,'on')
                   plot(handles.axes2,tspan(2),Tcoolant_current-273,'b.:','markersize',5);
                   axis(handles.axes2,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.axes2,'xtick',[])
                   set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                   pause(0.05);
                   
                   
                 end
                 set(handles.setpoint_inner_counter,'string',1);
                 set(handles.simulation_counter,'string',1);
Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%% Primary P && Secondry p: 
if get(handles.cntr_menu_p,'value')==2 && get(handles.cntr_menu_s,'value')==2;
    setpoint_outer=str2double(get(handles.set_point_p_edit,'string'));
      error=0;
    % set_point_p_edit    :  p==product
               if str2double(get(handles.setpoint_outer_counter,'string'))==0; 
                   hold(handles.axes1,'on');
                   plot(handles.axes1,[0   end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
               if str2double(get(handles.setpoint_outer_counter,'string'))==1; 
                   hold(handles.axes1,'on')
                   plot(handles.axes1,[-end_simulation_time/10 0],[previous_setpoint_outer    previous_setpoint_outer],'m');
                   plot(handles.axes1,[0    0],[previous_setpoint_outer     setpoint_outer],'m');
                   plot(handles.axes1,[0    end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
        
     
    % P= Primary loop
    % S= secondary loop
                t_sim=0:sample_rate:end_simulation_time;
                setpoint_p=str2double(get(handles.set_point_p_edit,'string'));
                setpoint_p=setpoint_p+273;
                controllergain_p=str2double(get(handles.kc_edit_p,'string'));
                controllergain_s=str2double(get(handles.kc_edit_s,'string'));
                T_current=x_ss(2);
                Tcoolant_current=x_ss(3);

                
                 initial_qc=str2double(get(handles.jacket_flowrate_pic,'string'));
                 
            for i=1:length(t_for_simulation)
        % PI concept:
                   currenterror = setpoint_p - T_current;
                   error=error + setpoint_p - T_current;
                   controller_output = controllergain_p* currenterror+273+50 ;
                   qc =   initial_qc + (controller_output - Tcoolant_current)*controllergain_s;
                   if qc>70
                       qc=70;
                   end
                   if qc<=0
                       qc=0.01;
                   end
                   set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                   
                   
                   tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  Tcoolant_current=x(2,3);
                  T_product_store=[T_product_store T_current];
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
%                   T_current = x(2,2);
%                    Tcoolant_current=x(2,3);
                   % plotting:
                   hold(handles.axes1,'on')
                   plot(handles.axes1,tspan(2),T_current-273,'r.:','markersize',4.8);
                   axis(handles.axes1,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));
                   

                   hold(handles.axes2,'on')
                   plot(handles.axes2,tspan(2),Tcoolant_current-273,'b.:','markersize',5);
                   axis(handles.axes2,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.axes2,'xtick',[])
                   set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                   pause(0.05);
           end
                  set(handles.setpoint_outer_counter,'string',1);
                  set(handles.simulation_counter,'string',1);
Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%% Primary PI && Secondry p: 
if get(handles.cntr_menu_p,'value')==3 && get(handles.cntr_menu_s,'value')==2;
    setpoint_outer=str2double(get(handles.set_point_p_edit,'string'));
      error=0;
    % set_point_p_edit    :  p==product
               if str2double(get(handles.setpoint_outer_counter,'string'))==0; 
                   hold(handles.axes1,'on');
                   plot(handles.axes1,[0   end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
               if str2double(get(handles.setpoint_outer_counter,'string'))==1; 
                   hold(handles.axes1,'on')
                   plot(handles.axes1,[-end_simulation_time/10 0],[previous_setpoint_outer    previous_setpoint_outer],'m');
                   plot(handles.axes1,[0    0],[previous_setpoint_outer     setpoint_outer],'m');
                   plot(handles.axes1,[0    end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
        
     
    % P= Primary loop
    % S= secondary loop
                t_sim=0:sample_rate:end_simulation_time;
                setpoint_p=str2double(get(handles.set_point_p_edit,'string'));
                setpoint_p=setpoint_p+273;
                controllergain_p=str2double(get(handles.kc_edit_p,'string'));
                controllergain_s=str2double(get(handles.kc_edit_s,'string'));
                T_current=x_ss(2);
                Tcoolant_current=x_ss(3);
                
                reset_time_p=str2double(get(handles.reset_time_edit_p,'string'));
                
                 initial_qc=str2double(get(handles.jacket_flowrate_pic,'string'));
                 
            for i=1:length(t_for_simulation)
        % PI concept:
                   currenterror = setpoint_p - T_current;
                   error=error + setpoint_p - T_current;
                   controller_output = controllergain_p* currenterror  +   (sample_rate*controllergain_p/reset_time_p)*error +273+50;
                   qc =   initial_qc + (controller_output - Tcoolant_current)*controllergain_s;
                   if qc>70
                       qc=70;
                   end
                   if qc<=0
                       qc=0.01;
                   end
                   set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                   
                   
                   tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  Tcoolant_current=x(2,3);
                  T_product_store=[T_product_store T_current];
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
%                   T_current = x(2,2);
%                    Tcoolant_current=x(2,3);
                   % plotting:
                   hold(handles.axes1,'on')
                   plot(handles.axes1,tspan(2),T_current-273,'r.:','markersize',4.8);
                   axis(handles.axes1,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));
                   

                   hold(handles.axes2,'on')
                   plot(handles.axes2,tspan(2),Tcoolant_current-273,'b.:','markersize',5);
                   axis(handles.axes2,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.axes2,'xtick',[])
                   set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                   pause(0.05);
           end
                  set(handles.setpoint_outer_counter,'string',1);
                  set(handles.simulation_counter,'string',1);
Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%% Primary PID && Secondry P: 

if get(handles.cntr_menu_p,'value')==4 && get(handles.cntr_menu_s,'value')==2;
    % P= Primary loop
    % S= secondary loop
        setpoint_inner=str2double(get(handles.set_point_s_edit,'string'));
        % set_point_p_edit    :  p==product
               if str2double(get(handles.setpoint_outer_counter,'string'))==0; 
                   hold(handles.axes1,'on');
                   plot(handles.axes1,[0   end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
               if str2double(get(handles.setpoint_outer_counter,'string'))==1; 
                   hold(handles.axes1,'on')
                   plot(handles.axes1,[-end_simulation_time/10 0],[previous_setpoint_outer    previous_setpoint_outer],'m');
                   plot(handles.axes1,[0    0],[previous_setpoint_outer     setpoint_outer],'m');
                   plot(handles.axes1,[0    end_simulation_time],[setpoint_outer     setpoint_outer],'m');
                   previous_setpoint_outer=setpoint_outer;
               end 
               
              

                setpoint_s=str2double(get(handles.set_point_s_edit,'string'));
                setpoint_s = setpoint_s + 273;
                controllergain_s=str2double(get(handles.kc_edit_s,'string'));

                controllerbias_s=str2double(get(handles.contoroller_bias_edit_s,'string'));

                Tcoolant_current=x_ss(3);

                 error=0;
                t_sim=0:sample_rate:end_simulation_time;
                setpoint_p=str2double(get(handles.set_point_p_edit,'string'));
                setpoint_p=setpoint_p+273;
                controllergain_p=str2double(get(handles.kc_edit_p,'string'));
                reset_time_p=str2double(get(handles.reset_time_edit_p,'string'));
                
                derive_time_p=str2double(get(handles.derive_time_edit_p,'string')); 
                T_current=x_ss(2);
                
                initial_qc=str2double(get(handles.jacket_flowrate_pic,'string'));

                previouserror = setpoint_p - T_current;
                
                 for i=1:length(t_for_simulation)
        % PID concept:
                   
                   currenterror=setpoint_p - T_current;
                   error=error + setpoint_p - T_current;
                   controller_output = controllergain_p* currenterror  +   (sample_rate*controllergain_p/reset_time_p)*error + (controllergain_p*derive_time_p/sample_rate)*(currenterror-previouserror)+273+50;
                   qc =   initial_qc + (controller_output - Tcoolant_current)*controllergain_s;
                   
                   
                   previouserror=currenterror;
                   
  
                  if qc>80
                       qc=80;
                   end
                   if qc<=0
                       qc=0.01;
                   end
                   set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                   
                   
                   tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  T_product_store=[T_product_store T_current];
                  Tcoolant_current=x(2,3);
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
%                   T_current = x(2,2);
%                    Tcoolant_current=x(2,3);
                   % plotting:
                   hold(handles.axes1,'on')
                   plot(handles.axes1,tspan(2),T_current-273,'r.:','markersize',4.8);
                   axis(handles.axes1,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));
                   

                   hold(handles.axes2,'on')
                   plot(handles.axes2,tspan(2),Tcoolant_current-273,'b.:','markersize',5);
                   axis(handles.axes2,[-end_simulation_time/10 end_simulation_time 30 120]);
                   set(handles.axes2,'xtick',[])
                   set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                   pause(0.05);
                   
                   
                 end
                 set(handles.setpoint_inner_counter,'string',1);
                 set(handles.simulation_counter,'string',1);
Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
end


set(handles.simulation_counter,'string',1);


 
 a=get(handles.grid_on,'checked');
 switch a
     case 'on'
         set(handles.axes1,'ygrid','on')
         set(handles.axes1,'xgrid','on')
         
         set(handles.axes2,'ygrid','on')
         set(handles.axes2,'xgrid','on')
         
        
     case 'off'
         set(handles.axes1,'ygrid','off')
         set(handles.axes1,'xgrid','off')
         
         set(handles.axes2,'ygrid','off')
         set(handles.axes2,'xgrid','off')
 end


function outlet_flowrate_Callback(hObject, eventdata, handles)
% hObject    handle to outlet_flow_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of outlet_flow_edit as text
%        str2double(get(hObject,'String')) returns contents of outlet_flow_edit as a double


% --- Executes during object creation, after setting all properties.
function outlet_flowrate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outlet_flow_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dist_temp_Callback(hObject, eventdata, handles)
% hObject    handle to dist_temp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dist_temp as text
%        str2double(get(hObject,'String')) returns contents of dist_temp as a double


% --- Executes during object creation, after setting all properties.
function dist_temp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dist_temp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function optionn_Callback(hObject, eventdata, handles)
% hObject    handle to optionn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function time_option_Callback(hObject, eventdata, handles)
% hObject    handle to time_option (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

 prompt={' End simulation Time (min) : ','Sample rate (min) :'};
   name=' Time Options: ';
   numlines=1;
     defaultanswer={get(handles.end_time_hidden,'string'),get(handles.sample_rate_hidden,'string')};

   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end

   % Im going to write these variables in 3 hidden texts , so that I can
   % call the in any functions!!
%    start_time=str2double(answer{1});
%     set(handles.start_simulation_hidden,'string',start_time)
   end_simulation_time=str2double(answer{1});
   set(handles.end_time_hidden,'string',end_simulation_time)
  sample_rate=str2double(answer{2});
  if sample_rate>2
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
   % figure FIG is destroyed (closed)
      uiwait(errordlg('Sample Rate Can`t Be Greater Than 2min. Because Of Accuracy Drop. '));
      set(handles.sample_rate_hidden,'string',2)
      time_option_Callback(hObject, eventdata, handles)
  end
  

  set(handles.sample_rate_hidden,'string',sample_rate);


% --- Executes on selection change in cntr_menu_p.
function cntr_menu_p_Callback(hObject, eventdata, handles)
% hObject    handle to cntr_menu_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cntr_menu_p contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cntr_menu_p

if get(handles.cntr_menu_p,'value')==1;
%       axes(handles.axes3);
%     imshow('distillation.jpg')
 set(handles.set_point_p_static,'visible','off');
 set(handles.set_point_p_edit,'visible','off');
 set(handles.outlet_flow_edit,'visible','on');
 set(handles.outlet_flow_static,'visible','on');
  set(handles.gc_static_p,'visible','off');
set(handles.kc_edit_p,'visible','off');
 set(handles.one_pluse_p,'visible','off');
 set(handles.line_p,'visible','off');
 set(handles.reset_time_edit_p,'visible','off');
 set(handles.s_reset_time_static_p,'visible','off');
 set(handles.one_reset_time_p,'visible','off');
 set(handles.plus_p,'visible','off');
 set(handles.derive_time_edit_p,'visible','off');
  set(handles.s_derive_time_static_p,'visible','off');
 set(handles.contoroller_bias_edit_p,'visible','off');
 set(handles.contoroller_bias_static_p,'visible','off');

end

%%%%%% P Only p
if get(handles.cntr_menu_p,'value')==2;
%     axes(handles.axes3);
%     imshow('distillationp.jpg')
    set(handles.set_point_p_static,'visible','on');
 set(handles.set_point_p_edit,'visible','on');
 set(handles.outlet_flow_edit,'visible','off');
 set(handles.outlet_flow_static,'visible','off');
  set(handles.gc_static_p,'visible','on');
set(handles.kc_edit_p,'visible','on');
 set(handles.one_pluse_p,'visible','off');
 set(handles.line_p,'visible','off');
 set(handles.reset_time_edit_p,'visible','off');
 set(handles.s_reset_time_static_p,'visible','off');
 set(handles.one_reset_time_p,'visible','off');
 set(handles.plus_p,'visible','off');
 set(handles.derive_time_edit_p,'visible','off');
  set(handles.s_derive_time_static_p,'visible','off');
 set(handles.contoroller_bias_edit_p,'visible','on');
 set(handles.contoroller_bias_static_p,'visible','on');
end


% PI
if get(handles.cntr_menu_p,'value')==3;
    set(handles.set_point_p_static,'visible','on');
 set(handles.set_point_p_edit,'visible','on');
 set(handles.outlet_flow_edit,'visible','off');
 set(handles.outlet_flow_static,'visible','off');
  set(handles.gc_static_p,'visible','on');
set(handles.kc_edit_p,'visible','on');

 set(handles.one_pluse_p,'string',' (1+ ');
 set(handles.one_pluse_p,'visible','on');
 
 set(handles.line_p,'visible','on');
 set(handles.reset_time_edit_p,'visible','on');
 set(handles.s_reset_time_static_p,'visible','on');
 set(handles.one_reset_time_p,'visible','on');
 
 set(handles.plus_p,'visible','on');
 set(handles.plus_p,'string',' ) ');
 
 set(handles.derive_time_edit_p,'visible','off');
  set(handles.s_derive_time_static_p,'visible','off');
 set(handles.contoroller_bias_edit_p,'visible','off');
 set(handles.contoroller_bias_static_p,'visible','off');
end

% PID
if get(handles.cntr_menu_p,'value')==4;
    set(handles.set_point_p_static,'visible','on');
 set(handles.set_point_p_edit,'visible','on');
 set(handles.outlet_flow_edit,'visible','off');
 set(handles.outlet_flow_static,'visible','off');
  set(handles.gc_static_p,'visible','on');
set(handles.kc_edit_p,'visible','on');

 set(handles.one_pluse_p,'string',' (1+ ');
 set(handles.one_pluse_p,'visible','on');
 
 set(handles.line_p,'visible','on');
 set(handles.reset_time_edit_p,'visible','on');
 set(handles.s_reset_time_static_p,'visible','on');
 set(handles.one_reset_time_p,'visible','on');
 
 set(handles.plus_p,'visible','on');
 set(handles.plus_p,'string',' + ');
 
 set(handles.derive_time_edit_p,'visible','on');
  set(handles.s_derive_time_static_p,'visible','on');
 set(handles.contoroller_bias_edit_p,'visible','off');
 set(handles.contoroller_bias_static_p,'visible','off');
end

if get(handles.cntr_menu_p,'value')~=1
 set(handles.set_point_s_static,'visible','off');
 set(handles.set_point_s_edit,'visible','off');
end

if get(handles.cntr_menu_p,'value')==1 && get(handles.cntr_menu_s,'value')~=1
 set(handles.set_point_s_static,'visible','on');
 set(handles.set_point_s_edit,'visible','on');
end

% --- Executes during object creation, after setting all properties.
function cntr_menu_p_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cntr_menu_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function outlet_flow_edit_Callback(hObject, eventdata, handles)
% hObject    handle to outlet_flow_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of outlet_flow_edit as text
%        str2double(get(hObject,'String')) returns contents of outlet_flow_edit as a double


% --- Executes during object creation, after setting all properties.
function outlet_flow_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outlet_flow_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function set_point_p_edit_Callback(hObject, eventdata, handles)
% hObject    handle to set_point_p_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of set_point_p_edit as text
%        str2double(get(hObject,'String')) returns contents of set_point_p_edit as a double


% --- Executes during object creation, after setting all properties.
function set_point_p_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to set_point_p_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function kc_edit_p_Callback(hObject, eventdata, handles)
% hObject    handle to kc_edit_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of kc_edit_p as text
%        str2double(get(hObject,'String')) returns contents of kc_edit_p as a double


% --- Executes during object creation, after setting all properties.
function kc_edit_p_CreateFcn(hObject, eventdata, handles)
% hObject    handle to kc_edit_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function reset_time_edit_p_Callback(hObject, eventdata, handles)
% hObject    handle to reset_time_edit_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of reset_time_edit_p as text
%        str2double(get(hObject,'String')) returns contents of reset_time_edit_p as a double


% --- Executes during object creation, after setting all properties.
function reset_time_edit_p_CreateFcn(hObject, eventdata, handles)
% hObject    handle to reset_time_edit_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function derive_time_edit_p_Callback(hObject, eventdata, handles)
% hObject    handle to derive_time_edit_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of derive_time_edit_p as text
%        str2double(get(hObject,'String')) returns contents of derive_time_edit_p as a double


% --- Executes during object creation, after setting all properties.
function derive_time_edit_p_CreateFcn(hObject, eventdata, handles)
% hObject    handle to derive_time_edit_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function contoroller_bias_edit_p_Callback(hObject, eventdata, handles)
% hObject    handle to contoroller_bias_edit_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of contoroller_bias_edit_p as text
%        str2double(get(hObject,'String')) returns contents of contoroller_bias_edit_p as a double


% --- Executes during object creation, after setting all properties.
function contoroller_bias_edit_p_CreateFcn(hObject, eventdata, handles)
% hObject    handle to contoroller_bias_edit_p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in cntr_menu_s.
function cntr_menu_s_Callback(hObject, eventdata, handles)
% hObject    handle to cntr_menu_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns cntr_menu_s contents as cell array
%        contents{get(hObject,'Value')} returns selected item from cntr_menu_s
if get(handles.cntr_menu_s,'value')==1;
%       axes(handles.axes3);
%     imshow('distillation.jpg')
 set(handles.set_point_s_static,'visible','off');
 set(handles.set_point_s_edit,'visible','off');
  set(handles.gc_static_s,'visible','off');
set(handles.kc_edit_s,'visible','off');
 set(handles.one_pluse_s,'visible','off');
 set(handles.line_s,'visible','off');
 set(handles.reset_time_edit_s,'visible','off');
 set(handles.s_reset_time_static_s,'visible','off');
 set(handles.one_reset_time_s,'visible','off');
 set(handles.plus_s,'visible','off');
 set(handles.derive_time_edit_s,'visible','off');
  set(handles.s_derive_time_static_s,'visible','off');
 set(handles.contoroller_bias_edit_s,'visible','off');
 set(handles.contoroller_bias_static_s,'visible','off');

end

%%%%%% P Only p
if get(handles.cntr_menu_s,'value')==2;
%     axes(handles.axes3);
%     imshow('distillationp.jpg')
if get(handles.cntr_menu_p,'value')==1;
 set(handles.set_point_s_static,'visible','on');
 set(handles.set_point_s_edit,'visible','on');
end
  set(handles.gc_static_s,'visible','on');
set(handles.kc_edit_s,'visible','on');
 set(handles.one_pluse_s,'visible','off');
 set(handles.line_s,'visible','off');
 set(handles.reset_time_edit_s,'visible','off');
 set(handles.s_reset_time_static_s,'visible','off');
 set(handles.one_reset_time_s,'visible','off');
 set(handles.plus_s,'visible','off');
 set(handles.derive_time_edit_s,'visible','off');
  set(handles.s_derive_time_static_s,'visible','off');
 set(handles.contoroller_bias_edit_s,'visible','on');
 set(handles.contoroller_bias_static_s,'visible','on');
end


% PI
if get(handles.cntr_menu_s,'value')==3;
if get(handles.cntr_menu_p,'value')==1;
 set(handles.set_point_s_static,'visible','on');
 set(handles.set_point_s_edit,'visible','on');
end
  set(handles.gc_static_s,'visible','on');
set(handles.kc_edit_s,'visible','on');

 set(handles.one_pluse_s,'string',' (1+ ');
 set(handles.one_pluse_s,'visible','on');
 
 set(handles.line_s,'visible','on');
 set(handles.reset_time_edit_s,'visible','on');
 set(handles.s_reset_time_static_s,'visible','on');
 set(handles.one_reset_time_s,'visible','on');
 
 set(handles.plus_s,'visible','on');
 set(handles.plus_s,'string',' ) ');
 
 set(handles.derive_time_edit_s,'visible','off');
  set(handles.s_derive_time_static_s,'visible','off');
 set(handles.contoroller_bias_edit_s,'visible','off');
 set(handles.contoroller_bias_static_s,'visible','off');
end

% PID
if get(handles.cntr_menu_s,'value')==4;
if get(handles.cntr_menu_p,'value')==1;
 set(handles.set_point_s_static,'visible','on');
 set(handles.set_point_s_edit,'visible','on');
end

  set(handles.gc_static_s,'visible','on');
set(handles.kc_edit_s,'visible','on');

 set(handles.one_pluse_s,'string',' (1+ ');
 set(handles.one_pluse_s,'visible','on');
 
 set(handles.line_s,'visible','on');
 set(handles.reset_time_edit_s,'visible','on');
 set(handles.s_reset_time_static_s,'visible','on');
 set(handles.one_reset_time_s,'visible','on');
 
 set(handles.plus_s,'visible','on');
 set(handles.plus_s,'string',' + ');
 
 set(handles.derive_time_edit_s,'visible','on');
  set(handles.s_derive_time_static_s,'visible','on');
 set(handles.contoroller_bias_edit_s,'visible','off');
 set(handles.contoroller_bias_static_s,'visible','off');
end



% --- Executes during object creation, after setting all properties.
function cntr_menu_s_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cntr_menu_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function set_point_s_edit_Callback(hObject, eventdata, handles)
% hObject    handle to set_point_s_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of set_point_s_edit as text
%        str2double(get(hObject,'String')) returns contents of set_point_s_edit as a double


% --- Executes during object creation, after setting all properties.
function set_point_s_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to set_point_s_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function kc_edit_s_Callback(hObject, eventdata, handles)
% hObject    handle to kc_edit_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of kc_edit_s as text
%        str2double(get(hObject,'String')) returns contents of kc_edit_s as a double


% --- Executes during object creation, after setting all properties.
function kc_edit_s_CreateFcn(hObject, eventdata, handles)
% hObject    handle to kc_edit_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function reset_time_edit_s_Callback(hObject, eventdata, handles)
% hObject    handle to reset_time_edit_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of reset_time_edit_s as text
%        str2double(get(hObject,'String')) returns contents of reset_time_edit_s as a double


% --- Executes during object creation, after setting all properties.
function reset_time_edit_s_CreateFcn(hObject, eventdata, handles)
% hObject    handle to reset_time_edit_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function derive_time_edit_s_Callback(hObject, eventdata, handles)
% hObject    handle to derive_time_edit_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of derive_time_edit_s as text
%        str2double(get(hObject,'String')) returns contents of derive_time_edit_s as a double


% --- Executes during object creation, after setting all properties.
function derive_time_edit_s_CreateFcn(hObject, eventdata, handles)
% hObject    handle to derive_time_edit_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function contoroller_bias_edit_s_Callback(hObject, eventdata, handles)
% hObject    handle to contoroller_bias_edit_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of contoroller_bias_edit_s as text
%        str2double(get(hObject,'String')) returns contents of contoroller_bias_edit_s as a double


% --- Executes during object creation, after setting all properties.
function contoroller_bias_edit_s_CreateFcn(hObject, eventdata, handles)
% hObject    handle to contoroller_bias_edit_s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function ziegler_Callback(hObject, eventdata, handles)
% hObject    handle to ziegler (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function ziegler_pi_Callback(hObject, eventdata, handles)
% hObject    handle to ziegler_pi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global T_current_store  sample_rate_for_ziegler controllergain_for_ziegler

    if str2double(get(handles.primary_p_flag,'string'))~=1
        errordlg('No Data From P only Simulation. For Ziegler Nicholes Tunnig,You Should First Get Data From Primary Closed Loop by P only,And Secondary Manual Mode.', ' Error: ');
        return
    end

T_max=[];
peak_time=[];
for i=2:length(T_current_store)-2
    if T_current_store(i)>T_current_store(i-1) && T_current_store(i)>T_current_store(i+1)
         T_max=[T_max T_current_store];
         peak_time=[peak_time sample_rate_for_ziegler*i];
    end
    if length(peak_time)>=4
        break
    end
end

Pu=((peak_time(2)-peak_time(1))+(peak_time(3)-peak_time(2))+(peak_time(4)-peak_time(3)))/3;

 set(handles.Pu_static,'visible','on');
 set(handles.Pu_edit,'string',sprintf('%0.2f',Pu));
 set(handles.Pu_edit,'visible','on');
 
 Ku=controllergain_for_ziegler;
 
 set(handles.Ku_static,'visible','on');
 set(handles.Ku_edit,'string',sprintf('%0.2f',Ku));
 set(handles.Ku_edit,'visible','on');
 
 
 set(handles.cntr_menu_p,'value',3);
 set(handles.set_point_p_static,'visible','on');
 set(handles.set_point_p_edit,'visible','on');
 set(handles.outlet_flow_edit,'visible','off');
 set(handles.outlet_flow_static,'visible','off');
 set(handles.gc_static_p,'visible','on');
 set(handles.kc_edit_p,'visible','on');
 set(handles.one_pluse_p,'string',' (1+ ');
 set(handles.one_pluse_p,'visible','on');
 set(handles.line_p,'visible','on');
 set(handles.reset_time_edit_p,'visible','on');
 set(handles.s_reset_time_static_p,'visible','on');
 set(handles.one_reset_time_p,'visible','on');
 set(handles.plus_p,'visible','on');
 set(handles.plus_p,'string',' ) ');
 set(handles.derive_time_edit_p,'visible','off');
 set(handles.s_derive_time_static_p,'visible','off');
 set(handles.contoroller_bias_edit_p,'visible','off');
 set(handles.contoroller_bias_static_p,'visible','off');
 
  sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
  set(handles.kc_edit_p,'string',sprintf('%0.2f',Ku*0.35/3));
  set(handles. reset_time_edit_p,'string',sprintf('%0.1f',Pu*60/(sample_rate*60)));
% --------------------------------------------------------------------
function ziegler_pid_Callback(hObject, eventdata, handles)
% hObject    handle to ziegler_pid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global T_current_store  sample_rate_for_ziegler controllergain_for_ziegler

    if str2double(get(handles.primary_p_flag,'string'))~=1
        errordlg('No Data From P only Simulation. For Ziegler Nicholes Tunnig,You Should First Get Data From Primary Closed Loop by P only,And Secondary Manual Mode.', ' Error: ');
        return
    end
    
T_max=[];
peak_time=[];
for i=2:length(T_current_store)-2
    if T_current_store(i)>T_current_store(i-1) && T_current_store(i)>T_current_store(i+1)
         T_max=[T_max T_current_store];
         peak_time=[peak_time sample_rate_for_ziegler*i];
    end
    if length(peak_time)>=4
        break
    end
end

Pu=((peak_time(2)-peak_time(1))+(peak_time(3)-peak_time(2))+(peak_time(4)-peak_time(3)))/3;

 set(handles.Pu_static,'visible','on');
 set(handles.Pu_edit,'string',sprintf('%0.2f',Pu));
 set(handles.Pu_edit,'visible','on');
 
  Ku=controllergain_for_ziegler;
 
 set(handles.Ku_static,'visible','on');
 set(handles.Ku_edit,'string',sprintf('%0.2f',Ku));
 set(handles.Ku_edit,'visible','on');
 
 
set(handles.cntr_menu_p,'value',4);
    set(handles.set_point_p_static,'visible','on');
 set(handles.set_point_p_edit,'visible','on');
 set(handles.outlet_flow_edit,'visible','off');
 set(handles.outlet_flow_static,'visible','off');
  set(handles.gc_static_p,'visible','on');
set(handles.kc_edit_p,'visible','on');

 set(handles.one_pluse_p,'string',' (1+ ');
 set(handles.one_pluse_p,'visible','on');
 
 set(handles.line_p,'visible','on');
 set(handles.reset_time_edit_p,'visible','on');
 set(handles.s_reset_time_static_p,'visible','on');
 set(handles.one_reset_time_p,'visible','on');
 
 set(handles.plus_p,'visible','on');
 set(handles.plus_p,'string',' + ');
 
 set(handles.derive_time_edit_p,'visible','on');
  set(handles.s_derive_time_static_p,'visible','on');
 set(handles.contoroller_bias_edit_p,'visible','off');
 set(handles.contoroller_bias_static_p,'visible','off');
 sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
   set(handles.kc_edit_p,'string',sprintf('%0.2f',Ku*0.3/3));
  set(handles. reset_time_edit_p,'string',sprintf('%0.1f',Pu*60/(1.5*sample_rate*60)));
   set(handles.derive_time_edit_p,'string',sprintf('%0.1f',Pu*60/(10*sample_rate*60)));


% --------------------------------------------------------------------
function puls_test_Callback(hObject, eventdata, handles)
% hObject    handle to puls_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Ca_ss T_ss Tcoolant_ss x_ss
global Tcf qc qc_store Tcf_store
global Ca T Tcoolant
global previous_setpoint_outer  previous_setpoint_inner
global T_current_store  sample_rate_for_ziegler controllergain_for_ziegler
global z T_store1 T_store2 setpoint_difference  duration_time
% start_simulation_time=str2double(get(handles.start_simulation_hidden,'string'));
% end_simulation_time=str2double(get(handles.end_time_hidden,'string'));

 
    if get(handles.cntr_menu_p,'value')~=1 || get(handles.cntr_menu_s,'value')~=2 ;
        errordlg('Puls Test Is Only Available When Primary Loop Is In Manual Mode And Secondary Is Closed Loop By P Only', ' Error: ');
        return
    end
    
   prompt={' First Setpoint : ','Second Setpoint :','Second SetPoint Duration (min),' };
   name=' Puls Test : ';
   numlines=1;
 defaultanswer={get(handles.first_setpoint_model_hidden,'string'),get(handles.second_setpoint_model_hidden,'string'),get(handles.duration_fit_mode_hidden,'string')};
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   first_setpoint=str2double(answer{1});
   second_setpoint=str2double(answer{2});
   duration_time=str2double(answer{3});
   
          if first_setpoint>second_setpoint
      % uiwait :
      % UIWAIT(FIG) blocks execution until either UIRESUME is called or the
      % figure FIG is destroyed (closed)
      uiwait(errordlg('Second Setpoint Should Be Greater Than First One ', ' Error: '));
       puls_test_Callback(hObject, eventdata, handles)
      return
          end
          
          if first_setpoint>90 || second_setpoint>90
      uiwait(errordlg('Process setpoint should be less than 90 `C ', ' Error: '));
      puls_test_Callback(hObject, eventdata, handles)
      return
          end
          
          if first_setpoint<35 || second_setpoint<35
      uiwait(errordlg('Process  setpoint should be more than  35 `C ', ' Error: '));
      pulse_test_Callback(hObject, eventdata, handles)
       return
          end
          
          if duration_time<10
      uiwait(errordlg('It`s Better to choose a time more than 10min for duration time, so the system can reach its steady state', 'warning '));
          end

      set(handles.first_setpoint_model_hidden,'string',first_setpoint)
      set(handles.second_setpoint_model_hidden,'string',second_setpoint)
      set(handles.duration_fit_mode_hidden,'string',duration_time)

         %%%%%%%%%%%% reach initial variables with first setpoint :

cla(handles.axes1,'reset')
cla(handles.axes2,'reset')

% start_simulation_time=str2double(get(handles.start_simulation_hidden,'string'));
end_simulation_time=str2double(get(handles.end_time_hidden,'string'));
sample_rate=str2double(get(handles.sample_rate_hidden,'string'));

    t_for_simulation=[0:sample_rate:duration_time];
    
% 
qc=str2double(get(handles.outlet_flow_edit,'string'));
qc_store=[qc_store qc];
set(handles.jacket_flowrate_pic,'string',qc);

Tcf=str2double(get(handles.dist_temp,'string'));
Tcf=Tcf+273;
Tcf_store=[Tcf_store Tcf];

             if str2double(get(handles.simulation_counter,'string'))==0
    
Ca_ss = 0.51;
Ca=Ca_ss;

T_ss = 273+60;
T=T_ss;
Tcoolant_ss=273+50;
Tcoolant=Tcoolant_ss;
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
             end

                t_sim=0:sample_rate:end_simulation_time;
                setpoint_s = first_setpoint;
                setpoint_s = setpoint_s + 273;
                controllergain_s=str2double(get(handles.kc_edit_s,'string'));

                controllerbias_s=str2double(get(handles.contoroller_bias_edit_s,'string'));

                Tcoolant_current=x_ss(3);

                
             for i=1:length(t_for_simulation)
        % P concept:
                   currenterror= setpoint_s - Tcoolant_current;
                   qc =  controllerbias_s  +  controllergain_s * currenterror  ;
                   
                  if qc>80
                       qc=80;
                   end
                   if qc<=0
                       qc=0.01;
                   end

                   tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  Tcoolant_current=x(2,3);
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
             end
                     set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));
                     set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                     set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                     set(handles.simulation_counter,'string',1);
Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];


%%% ploting zero time:
 hold(handles.axes2,'on')
 plot(handles.axes2,[-duration_time/10  0],[first_setpoint first_setpoint],'m');
 plot(handles.axes2,[0 0],[first_setpoint second_setpoint],'m');
 plot(handles.axes2,[0 duration_time],[second_setpoint second_setpoint],'m');
 plot(handles.axes2,[duration_time  duration_time],[first_setpoint second_setpoint],'m');
 plot(handles.axes2,[duration_time  2*duration_time],[first_setpoint first_setpoint],'m');
  axis(handles.axes2,[-duration_time/10 2*duration_time first_setpoint-10 second_setpoint+10]);
  
 plot(handles.axes2,[-duration_time/10:sample_rate:0],linspace(first_setpoint,first_setpoint,length([-duration_time/10:sample_rate:0])),'b.:','markersize',5);
 hold(handles.axes1,'on')
 plot(handles.axes1,(-duration_time/10:sample_rate:0),linspace(T_ss-273,T_ss-273,length((-duration_time/10:sample_rate:0))),'r.:','markersize',5);
 axis(handles.axes1,[-duration_time/10 2*duration_time 30 120]);
 
 
 %%%%%%%%%%%%%%%%%  reaching second setpoint :
                set(handles.set_point_s_edit,'string',second_setpoint);
                t_sim=0:sample_rate:end_simulation_time;
                setpoint_s= second_setpoint;
                setpoint_s = setpoint_s + 273;
                controllergain_s=str2double(get(handles.kc_edit_s,'string'));
                controllerbias_s=str2double(get(handles.contoroller_bias_edit_s,'string'));

                Tcoolant_current=x_ss(3);
                T_store1=[];
                 for i=1:length(t_for_simulation)

                   currenterror= setpoint_s - Tcoolant_current;
                   qc =  controllerbias_s  +  controllergain_s * currenterror  ;

                  if qc>80
                       qc=80;
                   end
                   if qc<=0
                       qc=0.01;
                   end
                   set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                   

                  tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  T_store1 = [T_store1 T_current];
                  Tcoolant_current=x(2,3);
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
                   % plotting:
                   hold(handles.axes1,'on')
                   plot(handles.axes1,tspan(2),T_current-273,'r.:','markersize',4.8);
                   axis(handles.axes1,[-duration_time/10 2*duration_time 30 120]);
                   set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));

                   hold(handles.axes2,'on')
                   plot(handles.axes2,tspan(2),Tcoolant_current-273,'b.:','markersize',5);
                   axis(handles.axes2,[-duration_time/10 2*duration_time first_setpoint-10 second_setpoint+10]);
                   set(handles.axes2,'xtick',[])
                   set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                   pause(0.05);

                 end

Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];

%%%%%%%%%%%%%%%%%  reaching  first setpoint :
              set(handles.set_point_s_edit,'string',first_setpoint);
             
                t_for_simulation=[duration_time:sample_rate:2*duration_time];    
                t_sim=duration_time:sample_rate:2*duration_time;
                setpoint_s= first_setpoint;
                setpoint_s = setpoint_s + 273;

                Tcoolant_current=x_ss(3);
                T_store2=[];
                
                 for i=1:length(t_for_simulation)
                     
                   currenterror= setpoint_s - Tcoolant_current;
                   qc =  controllerbias_s  +  controllergain_s * currenterror  ;

                  if qc>80
                       qc=80;
                   end
                   if qc<=0
                       qc=0.01;
                   end
                   set(handles.jacket_flowrate_pic,'string',sprintf('%0.2f',qc));
                   

                  tspan=[t_sim(i) t_sim(i)+sample_rate t_sim(i)+2*sample_rate];
                  [t,x] = ode15s('cstr1',tspan,x_ss);
                  % Update states:

                  Ca_current =x(2,1);
                  T_current = x(2,2);
                  T_store2 = [T_store2 T_current];
                  Tcoolant_current=x(2,3);
                  x_ss = [Ca_current;T_current;Tcoolant_current];
                  x=x_ss;
                   % plotting:
                   hold(handles.axes1,'on')
                   plot(handles.axes1,tspan(2),T_current-273,'r.:','markersize',4.8);
                   axis(handles.axes1,[-duration_time/10 2*duration_time 30 120]);
                   set(handles.product_open_loop_temp_pic,'string',sprintf('%0.2f',T_current-273));

                   hold(handles.axes2,'on')
                   plot(handles.axes2,tspan(2),Tcoolant_current-273,'b.:','markersize',5);
                   axis(handles.axes2,[-duration_time/10 2*duration_time first_setpoint-10 second_setpoint+10]);
                   set(handles.axes2,'xtick',[])
                   set(handles.jacket_temp_pic,'string',sprintf('%0.2f',Tcoolant_current-273));
                   pause(0.05);

                 end

Ca_ss =x(1);
T_ss = x(2);
Tcoolant_ss=x(3);
x_ss = [Ca_ss;T_ss;Tcoolant_ss];
 

 %%%%%%%%%% Fitting :
% y2 : main tank
setpoint_difference=second_setpoint - first_setpoint;
u=linspace(setpoint_difference,setpoint_difference,length(T_store1));
u=transpose(u);
T_store1=transpose(T_store1);
% iddata makes y and u and sample interval into a variabe suitable for
% n4sid

z=iddata(T_store1,u,sample_rate);
   
    a=get(handles.grid_on,'checked');
 switch a
     case 'on'
         set(handles.axes1,'ygrid','on')
         set(handles.axes1,'xgrid','on')
         
         set(handles.axes2,'ygrid','on')
         set(handles.axes2,'xgrid','on')
         
        
     case 'off'
         set(handles.axes1,'ygrid','off')
         set(handles.axes1,'xgrid','off')
         
         set(handles.axes2,'ygrid','off')
         set(handles.axes2,'xgrid','off')
 end

fopdt_Callback(hObject, eventdata, handles)


function  fopdt_Callback(hObject, eventdata, handles)

global z T_store1 T_store2 setpoint_difference  duration_time
global k_for_tunning_parameters tow_for_tunning_parameters deadtime_for_tunning_parameters
   prompt={'Minimum Guess For Time constant (min) : ','Maximum Guess For Time constant (min) : ',' Minimum Guess For Dead Time: (min): ',' Maximum Guess For Dead Time: (min): '};
   name=' Parameters Limit: ';
   numlines=1;
   defaultanswer={get(handles.Tp1_min_guess_hidden,'string'),get(handles.Tp1_max_guess_hidden,'string'),get(handles.Td_min_guess_hidden,'string'),get(handles.Td_max_guess_hidden,'string')};
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1})
       uiwait( errordlg(' Maximum Guess Should Be Greater Than Minimum Guess ' ))
       fopdt_Callback(hObject, eventdata, handles)
       return
   end
      
   % I`m going to write new inputs in 4 hidden static texts to be saved for
    % next use:
   set(handles.Tp1_min_guess_hidden,'string',str2double(answer{1}))
   set(handles.Tp1_max_guess_hidden,'string',str2double(answer{2}))
   set(handles.Td_min_guess_hidden,'string',str2double(answer{3}))
   set(handles.Td_max_guess_hidden,'string',str2double(answer{4}))
   
   
set(handles.fit_model_title,'string', ' Waiting . . . ');
set(handles.fit_model_title,'foregroundColor',[1 0 0]);
set(handles.fit_model_title,'visible', ' on');

set(handles.gs_fit_model_static,'visible' , 'off' );
set(handles.parantez1,'visible' , 'off' );
set(handles.K,'visible' , 'off' );
set(handles.T,'visible' , 'off' );
set(handles.s_plus_one,'visible' , 'off' );
set(handles.model_exp,'visible' , 'off' );
set(handles.dead_time_fit_model,'visible' , 'off' );
set(handles.s_parantez,'visible' , 'off' );
set(handles.line_model,'visible' , 'off' );

model=pem(z,'P1D','Tp1',{'max',str2double(answer{2})},'Tp1',{'min',str2double(answer{1})},'Td',{'max',str2double(answer{4})},'Td',{'min',str2double(answer{3})});
% p1 means polonomyal first order

 k=model.kp.value;
 tow=model.Tp1.value;
 deadtime=model.Td.value;
 k2=(T_store1(length(T_store1))-T_store1(1))/setpoint_difference;
 
  % 2 floating point needed:
 tow=sprintf('%0.2f',tow);
 k2=sprintf('%0.2f',k2);
deadtime=sprintf('%0.2f',deadtime);
 
 
set(handles.fit_model_title,'string', ' First Order Parameters Plus Dead Time : ');
set(handles.fit_model_title,'foregroundColor',[0 0 0]);
% back to black!
set(handles.fit_model_title,'visible' , 'on' );


set(handles.gs_fit_model_static,'visible' , 'on' );
set(handles.parantez1,'visible' , 'on' );
set(handles.K,'visible' , 'on' );
set(handles.T,'visible' , 'on' );
set(handles.s_plus_one,'visible' , 'on' );
set(handles.model_exp,'visible' , 'on' );
set(handles.dead_time_fit_model,'visible' , 'on' );
set(handles.s_parantez,'visible' , 'on' );
set(handles.line_model,'visible' , 'on' );

set(handles.dead_time_fit_model,'string' ,deadtime);
set(handles.K,'string' , k2 );
set(handles.T,'string' , tow );


model2=tf([str2num(k2)*setpoint_difference],[str2num(tow) 1],'inputdelay',str2num(deadtime));
   model.kp.value=str2num(k2)*setpoint_difference;
   [yy1,tt]=step(model2,duration_time);
   yy1=yy1+ T_store1(1)-273;
   hold(handles.axes1,'on')
   plot(handles.axes1,tt,yy1,'k','markersize',5)
   
   [yy2,tt2]=step(model2,duration_time);
%    a=max(find(tt<0));
%    tt2=tt2(a:end);
%    yy2=yy2(a:end)-273;
   plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'k','markersize',5)

   
  pause(2)
question=questdlg(' Is The Model Satisfactory?  ',' Model ','Yes','No','Yes');
switch question
    case 'Yes'
set(handles.choose_model_history,'string',1);

k_for_tunning_parameters=str2double(k2);
tow_for_tunning_parameters=str2double(tow);
deadtime_for_tunning_parameters=str2double(deadtime);


set(handles.measured_data_text,'visible' , 'on' );
set(handles.estimated_model_text,'visible' , 'on' );

    case 'No'
         plot(handles.axes1,tt,yy1,'w','markersize',5)
         plot(handles.axes1,tt2+duration_time,-yy2+yy1(length(yy1)),'w','markersize',5)
          fopdt_Callback(hObject, eventdata, handles)
end


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function p_cohen_Callback(hObject, eventdata, handles)
% hObject    handle to p_cohen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters


if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end


set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');




tow=tow_for_tunning_parameters;
deadtime=deadtime_for_tunning_parameters;
k=k_for_tunning_parameters;

r=deadtime/tow;

kp=(1/(k*r))*(1+r/3);
kp=kp*8;

set(handles.controller_gain_number,'string',sprintf('%0.2f',kp));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.title_for_parameters,'string','Cohen-Coon P-only Parameters :');
set(handles.title_for_parameters,'visible','on');

% --------------------------------------------------------------------
function pi_cohen_Callback(hObject, eventdata, handles)
% hObject    handle to pi_cohen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters

if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end


set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');



tow=tow_for_tunning_parameters;
deadtime=deadtime_for_tunning_parameters;
k=k_for_tunning_parameters;

r=deadtime/tow;

kp=(1/(k*r))*(0.9+r/12);
reset_time_cohen=deadtime*(30+3*r)/(9+20*r);

kp=kp*8;
sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
reset_time_cohen=reset_time_cohen*sample_rate*60;

set(handles.controller_gain_number,'string',sprintf('%0.2f',kp));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.reset_time_number,'string',sprintf('%0.2f',reset_time_cohen));
set(handles.reset_time_number,'visible','on');
set(handles.reset_time_text_paramaters,'visible','on');

set(handles.title_for_parameters,'string','Cohen-Coon PI Parameters :');
set(handles.title_for_parameters,'visible','on');



% --------------------------------------------------------------------
function pid_cohen_Callback(hObject, eventdata, handles)
% hObject    handle to pid_cohen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters



if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end




set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');


sample_rate=str2double(get(handles.sample_rate_hidden,'string'));

tow=tow_for_tunning_parameters;
deadtime=deadtime_for_tunning_parameters;
k=k_for_tunning_parameters;

r=deadtime/tow;

kp=(1/(k*r))*(4/3+r/4);
kp=kp*8;
reset_time_cohen=deadtime*(32+6*r)/(13+8*r);
reset_time_cohen=reset_time_cohen*sample_rate*60;
derive_time_cohen = 4*deadtime/(11+2*r);
derive_time_cohen = derive_time_cohen*sample_rate*60;

set(handles.controller_gain_number,'string',sprintf('%0.2f',kp));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.reset_time_number,'string',sprintf('%0.2f',reset_time_cohen));
set(handles.reset_time_number,'visible','on');
set(handles.reset_time_text_paramaters,'visible','on');

set(handles.derive_time_number,'string',sprintf('%0.2f',derive_time_cohen));
set(handles.derive_time_number,'visible','on');
set(handles.derive_time_text_paramaters,'visible','on');

set(handles.title_for_parameters,'string','Cohen-Coon PID Parameters :');
set(handles.title_for_parameters,'visible','on');


% --------------------------------------------------------------------
function Untitled_6_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_8_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function p_iae_Callback(hObject, eventdata, handles)
% hObject    handle to p_iae (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters


if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end

   prompt={' Controller Gain Minimum Limit : ',' Controller Gain Maximum Limit : '};
   name=' Bonuds : ';
   numlines=1;
% reading default answers from 4 hidden texts:
     defaultanswer={get(handles.k_minimum_hidden,'string'),get(handles.k_maximum_hidden,'string')};
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1})
       uiwait( errordlg(' Maximum Limit Should Be Greater Than Minimum! ' ))
       p_iae_Callback(hObject, eventdata, handles)
       return
   end
  
   
  % I`m going to write new inputs in 4 hidden static texts to be saved for
    % next use:
   set(handles.k_minimum_hidden,'string',str2double(answer{1}))
   set(handles.k_maximum_hidden,'string',str2double(answer{2})) 
   
    k_minimum=str2double(answer{1});
    k_maximum=str2double(answer{2});

    
set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');
pause(0.0001)

set(handles.title_for_parameters,'string', ' Waiting . . . ');
set(handles.title_for_parameters,'visible' , 'on' );
pause(0.0001);

model=tf( k_for_tunning_parameters,[tow_for_tunning_parameters 1],'inputdelay', deadtime_for_tunning_parameters);

model=ss(model);
s=1000000000000000000;
for k=k_minimum:0.1:k_maximum
        c=k;
        forward=series(c,model);
        closedloop=feedback(forward,1);
        [yy,tt]=step(closedloop,800);
        deltat=tt(3)-tt(2);
        deltat=linspace(deltat,deltat,length(yy));
        deltat=transpose(deltat);
        error=1-yy;
        itae=deltat.*abs(error);
        temp=sum(itae);
        if temp <= min(s)
            K=k;
        end
        s=[s temp];
end

set(handles.title_for_parameters,'string', ' IAE method P Only :');

set(handles.contoroller_gain_text_paramaters,'visible' , 'on' );
set(handles.controller_gain_number,'string',K);
set(handles.controller_gain_number,'visible' , 'on' );

% --------------------------------------------------------------------
function pi_iae_Callback(hObject, eventdata, handles)
% hObject    handle to pi_iae (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters


if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end

   prompt={' Controller Gain Minimum Limit : ',' Controller Gain Maximum Limit : ', ' Reset Time Minimum Limit (sec) : ' , ' Reset Time Maximum Limit (sec) : ' };
   name=' Bonuds : ';
   numlines=1;
% reading default answers from 4 hidden texts:
     defaultanswer={get(handles.k_minimum_hidden,'string'),get(handles.k_maximum_hidden,'string'),get(handles.r_time_minimum_hidden,'string'),get(handles.r_time_maximum_hidden,'string')};
     
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1}) | str2double(answer{4}) <= str2double(answer{3})
        % uiwait :
       % UIWAIT(FIG) blocks execution until either UIRESUME is called or
       % th
       uiwait( errordlg(' Maximum Limit Should Be Greater Than Minimum! ' ))
       pi_iae_Callback(hObject, eventdata, handles)
       return
   end
  
   
  % I`m going to write new inputs in 4 hidden static texts to be saved for
    % next use:
   set(handles.k_minimum_hidden,'string',str2double(answer{1}))
   set(handles.k_maximum_hidden,'string',str2double(answer{2}))
   set(handles.r_time_minimum_hidden,'string',str2double(answer{3}))
   set(handles.r_time_maximum_hidden,'string',str2double(answer{4}))
   
   
    k_minimum=str2double(answer{1});
    k_maximum=str2double(answer{2});
    r_time_minimum=str2double(answer{3});
    r_time_maximum=str2double(answer{4});
    
set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');
pause(0.0001)
set(handles.title_for_parameters,'string', ' Waiting . . . ');

set(handles.title_for_parameters,'visible' , 'on' );
pause(0.0001);

model=tf( k_for_tunning_parameters,[tow_for_tunning_parameters 1],'inputdelay', deadtime_for_tunning_parameters);

model=ss(model);
s=1000000000000000000;
for k=k_minimum:0.1:k_maximum
    for reset_time=r_time_minimum:r_time_maximum
        c=tf([k*reset_time k],[reset_time 0]);
        forward=series(c,model);
        closedloop=feedback(forward,1);
        [yy,tt]=step(closedloop,800);
        deltat=tt(3)-tt(2);
        deltat=linspace(deltat,deltat,length(yy));
        deltat=transpose(deltat);
        error=1-yy;
        itae=deltat.*abs(error);
        temp=sum(itae);
        if temp <= min(s)
            K=k;
            Reset_Time=reset_time;
        end
        s=[s temp];
    end
end

set(handles.title_for_parameters,'string', ' IAE method PI Parameters :');

set(handles.contoroller_gain_text_paramaters,'visible' , 'on' );
set(handles.controller_gain_number,'string',K);
set(handles.controller_gain_number,'visible' , 'on' );
set(handles.reset_time_text_paramaters,'visible' , 'on' );
set(handles.reset_time_number,'string',Reset_Time);
set(handles.reset_time_number,'visible' , 'on' );


% --------------------------------------------------------------------
function pid_iae_Callback(hObject, eventdata, handles)
% hObject    handle to pid_iae (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters


if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end


   prompt={' Controller Gain Minimum Limit : ',' Controller Gain Maximum Limit : ', ' Reset Time Minimum Limit (sec) : ' , ' Reset Time Maximum Limit (sec) : ' ...
       , ' Derive Time Minimum Limit (sec) : ' , ' Derive Time Maximum Limit (sec) : ' };
   name=' Bonuds : ';
   numlines=1;
% reading default answers from 4 hidden texts:
     defaultanswer={get(handles.k_minimum_hidden,'string'),get(handles.k_maximum_hidden,'string'),get(handles.r_time_minimum_hidden,'string'),get(handles.r_time_maximum_hidden,'string')...
         get(handles.d_time_minimum_hidden,'string'),get(handles.d_time_maximum_hidden,'string')};
     
   answer=inputdlg(prompt,name,numlines,defaultanswer,'on');
   if size(answer)==[0 0]
       return
   end
   
   if str2double(answer{2}) <= str2double(answer{1}) || str2double(answer{4}) <= str2double(answer{3}) ...
           || str2double(answer{6}) <= str2double(answer{5})
        % uiwait :
       % UIWAIT(FIG) blocks execution until either UIRESUME is called or
       % th
       uiwait( errordlg(' Maximum Limit Should Be Greater Than Minimum! ' ))
        pid_iae_Callback(hObject, eventdata, handles)
       return
   end
  
   
  % I`m going to write new inputs in 4 hidden static texts to be saved for
    % next use:
   set(handles.k_minimum_hidden,'string',str2double(answer{1}))
   set(handles.k_maximum_hidden,'string',str2double(answer{2}))
   set(handles.r_time_minimum_hidden,'string',str2double(answer{3}))
   set(handles.r_time_maximum_hidden,'string',str2double(answer{4}))
   set(handles.d_time_minimum_hidden,'string',str2double(answer{5}))
   set(handles.d_time_maximum_hidden,'string',str2double(answer{6}))
   
    k_minimum=str2double(answer{1});
    k_maximum=str2double(answer{2});
    r_time_minimum=str2double(answer{3});
    r_time_maximum=str2double(answer{4});
    d_time_minimum=str2double(answer{5});
    d_time_maximum=str2double(answer{6});
    
    
set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');
pause(0.0001)
set(handles.title_for_parameters,'string', ' Waiting . . . ');

set(handles.title_for_parameters,'visible' , 'on' );
pause(0.0001);

model=tf( k_for_tunning_parameters,[tow_for_tunning_parameters 1],'inputdelay', deadtime_for_tunning_parameters);
model=pade(model,1);
model=ss(model);

s=1000000000000000000;
for k=k_minimum:0.1:k_maximum
    for reset_time=r_time_minimum:1:r_time_maximum
        for derive_time=d_time_minimum:1:d_time_maximum
            
        c=tf([k*reset_time*derive_time k*reset_time k],[reset_time 0]);
        forward=series(c,model);
        closedloop=feedback(forward,1);
        [yy,tt]=step(closedloop,800);
        deltat=tt(3)-tt(2);
        deltat=linspace(deltat,deltat,length(yy));
        deltat=transpose(deltat);
        error=1-yy;
        itae=deltat.*abs(error);
        temp=sum(itae);
        if temp <= min(s)
            K=k;
            Reset_Time=reset_time;
            Derive_Time=derive_time;
        end
        s=[s temp];
        end
    end
end

set(handles.title_for_parameters,'string', ' IAE method PID Parameters :');

set(handles.contoroller_gain_text_paramaters,'visible' , 'on' );
set(handles.controller_gain_number,'string',K);
set(handles.controller_gain_number,'visible' , 'on' );

set(handles.reset_time_text_paramaters,'visible' , 'on' );
set(handles.reset_time_number,'string',Reset_Time);
set(handles.reset_time_number,'visible' , 'on' );

set(handles.derive_time_text_paramaters,'visible' , 'on' );
set(handles.derive_time_number,'string',Derive_Time);
set(handles.derive_time_number,'visible' , 'on' );

% --------------------------------------------------------------------
function pi_imc_Callback(hObject, eventdata, handles)
% hObject    handle to pi_imc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global tow_for_tunning_parameters
global k_for_tunning_parameters
global deadtime_for_tunning_parameters

if str2double(get(handles.choose_model_history,'string'))~=1
 errordlg('You Should First Derive A Model For System With Puls Test And Fit Model Menu', ' Error: ');
 return 
end


set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');


%%%%%%%%%%%%%%%%%%%%%%%%% For First Order Plus Dead


% reset time eqauls to time constant in first order model:
set(handles.reset_time_number,'string',tow_for_tunning_parameters);


tow_c=max([0.8*deadtime_for_tunning_parameters        0.1*tow_for_tunning_parameters]);
k_imc=(1/k_for_tunning_parameters)  *   (tow_for_tunning_parameters/(tow_c  +  deadtime_for_tunning_parameters));

sample_rate=str2double(get(handles.sample_rate_hidden,'string'));
k_imc=k_imc*8;
tow=tow_for_tunning_parameters*sample_rate*60;

set(handles.controller_gain_number,'string',sprintf('%0.2f',k_imc));
set(handles.controller_gain_number,'visible','on');
set(handles.contoroller_gain_text_paramaters,'visible','on');

set(handles.reset_time_number,'string',sprintf('%0.2f',tow));
set(handles.reset_time_number,'visible','on');
set(handles.reset_time_text_paramaters,'visible','on');

set(handles.title_for_parameters,'string','IMC PI Parameters :');
set(handles.title_for_parameters,'visible','on');



% --------------------------------------------------------------------
function Untitled_11_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function grid_on_Callback(hObject, eventdata, handles)
% hObject    handle to grid_on (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

         set(handles.grid_on,'checked','on')
         set(handles.grid_off,'checked','off')
         set(handles.axes1,'ygrid','on')
         set(handles.axes1,'xgrid','on')
         set(handles.axes2,'ygrid','on')
         set(handles.axes2,'xgrid','on')
% --------------------------------------------------------------------
function grid_off_Callback(hObject, eventdata, handles)
% hObject    handle to grid_off (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

         set(handles.grid_on,'checked','off')
         set(handles.grid_off,'checked','on')
         set(handles.axes1,'ygrid','off')
         set(handles.axes1,'xgrid','off')  
         set(handles.axes2,'ygrid','off')
         set(handles.axes2,'xgrid','off')


% --------------------------------------------------------------------
function Untitled_9_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function file_new_Callback(hObject, eventdata, handles)
% hObject    handle to file_new (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Ca_ss T_ss Tcoolant_ss x_ss
global Tcf qc qc_store Tcf_store
global Ca T Tcoolant
global previous_setpoint_outer  previous_setpoint_inner
global T_current_store  sample_rate_for_ziegler controllergain_for_ziegler
global T_product_store

Ca_ss = 0.51;
Ca=Ca_ss;

T_ss = 273+60;
T=T_ss;
Tcoolant_ss=273+50;
Tcoolant=Tcoolant_ss;
x_ss = [Ca_ss;T_ss;Tcoolant_ss];

T_product_store=[];

set(handles.cntr_menu_p,'value',1);

 set(handles.set_point_p_static,'visible','off');
 set(handles.set_point_p_edit,'visible','off');
 set(handles.outlet_flow_edit,'visible','on');
 set(handles.outlet_flow_static,'visible','on');
  set(handles.gc_static_p,'visible','off');
set(handles.kc_edit_p,'visible','off');
 set(handles.one_pluse_p,'visible','off');
 set(handles.line_p,'visible','off');
 set(handles.reset_time_edit_p,'visible','off');
 set(handles.s_reset_time_static_p,'visible','off');
 set(handles.one_reset_time_p,'visible','off');
 set(handles.plus_p,'visible','off');
 set(handles.derive_time_edit_p,'visible','off');
  set(handles.s_derive_time_static_p,'visible','off');
 set(handles.contoroller_bias_edit_p,'visible','off');
 set(handles.contoroller_bias_static_p,'visible','off');
 
 
  set(handles.cntr_menu_s,'value',1);

 set(handles.set_point_s_static,'visible','off');
 set(handles.set_point_s_edit,'visible','off');
  set(handles.gc_static_s,'visible','off');
set(handles.kc_edit_s,'visible','off');
 set(handles.one_pluse_s,'visible','off');
 set(handles.line_s,'visible','off');
 set(handles.reset_time_edit_s,'visible','off');
 set(handles.s_reset_time_static_s,'visible','off');
 set(handles.one_reset_time_s,'visible','off');
 set(handles.plus_s,'visible','off');
 set(handles.derive_time_edit_s,'visible','off');
  set(handles.s_derive_time_static_s,'visible','off');
 set(handles.contoroller_bias_edit_s,'visible','off');
 set(handles.contoroller_bias_static_s,'visible','off');
 
 set(handles.gs_fit_model_static,'visible' , 'off' );
set(handles.parantez1,'visible' , 'off' );
set(handles.K,'visible' , 'off' );
set(handles.T,'visible' , 'off' );
set(handles.s_plus_one,'visible' , 'off' );
set(handles.model_exp,'visible' , 'off' );
set(handles.dead_time_fit_model,'visible' , 'off' );
set(handles.s_parantez,'visible' , 'off' );
set(handles.line_model,'visible' , 'off' );
set(handles.fit_model_title,'visible', ' off');



set(handles.measured_data_text,'visible', ' off');
set(handles.estimated_model_text,'visible', ' off');
set(handles.max_temp_static,'visible', ' off');
set(handles.min_temp_static,'visible', ' off');
set(handles.text117,'visible', ' off');
set(handles.text118,'visible', ' off');
set(handles.fit_model_title,'visible', ' off');
set(handles.fit_model_title,'visible', ' off');
set(handles.fit_model_title,'visible', ' off');


set(handles.dist_temp,'string', 30);

set(handles.product_open_loop_temp_pic,'string', 60);
set(handles.jacket_temp_pic,'string',50);
set(handles.jacket_flowrate_pic,'string',13.77);
set(handles.outlet_flow_edit,'string',13.77);

set(handles.k_minimum_hidden,'string',0.3);
set(handles.k_maximum_hidden,'string',2);
set(handles.r_time_minimum_hidden,'string',5);

set(handles.r_time_maximum_hidden,'string',20);
set(handles.d_time_minimum_hidden,'string',1);
set(handles.d_time_maximum_hidden,'string',1.3);

set(handles.sample_rate_hidden,'string',0.2);
set(handles.end_time_hidden,'string',40);
set(handles.simulation_counter,'string',0);
set(handles.setpoint_inner_counter,'string',0);

set(handles.setpoint_outer_counter,'string',0);

set(handles.primary_p_flag,'string',0);
set(handles.choose_model_history,'string',0);
set(handles.first_setpoint_model_hidden,'string',50);
set(handles.second_setpoint_model_hidden,'string',60);
set(handles.duration_fit_mode_hidden,'string',30);

set(handles.Tp1_min_guess_hidden,'string',0.5);
set(handles.Tp1_max_guess_hidden,'string',5);
set(handles.Td_min_guess_hidden,'string',0.5);

set(handles.Td_max_guess_hidden,'string',1.3);



set(handles.contoroller_gain_text_paramaters,'visible','off');
set(handles.controller_gain_number,'visible','off');

set(handles.reset_time_text_paramaters,'visible','off');
set(handles.reset_time_number,'visible','off');

set(handles.derive_time_text_paramaters,'visible','off');
set(handles.derive_time_number,'visible','off');

set(handles.title_for_parameters,'visible','off');



set(handles.Pu_static,'visible','off');
set(handles.Pu_edit,'visible','off');
set(handles.Ku_static,'visible','off');
set(handles.Ku_edit,'visible','off');


cla(handles.axes1,'reset')
cla(handles.axes2,'reset')
% --------------------------------------------------------------------
function print_figure_Callback(hObject, eventdata, handles)
% hObject    handle to print_figure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printpreview(CSTR)

% --------------------------------------------------------------------
function file_exit_Callback(hObject, eventdata, handles)
% hObject    handle to file_exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a=questdlg(' Do You Want To Exit ? ',' Exit ','Yes','No','Yes');
switch a
    case 'Yes'
        close( 'CSTR')
end


% --- Executes on button press in max_temp.
function max_temp_Callback(hObject, eventdata, handles)
% hObject    handle to max_temp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global T_product_store

if str2double(get(handles.simulation_counter,'string'))~=1
 errordlg('There Is No Data!', ' Error: ');
 return 
end

set(handles.max_temp_static,'string',sprintf('%0.2f',max(T_product_store)-273));
set(handles.max_temp_static,'visible','on');
set(handles.text117,'visible','on');

% --- Executes on button press in min_temp.
function min_temp_Callback(hObject, eventdata, handles)
% hObject    handle to min_temp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global T_product_store

if str2double(get(handles.simulation_counter,'string'))~=1
 errordlg('There Is No Data!', ' Error: ');
 return 
end

set(handles.min_temp_static,'string',sprintf('%0.2f',min(T_product_store)-273));
set(handles.min_temp_static,'visible','on');
set(handles.text118,'visible','on');
